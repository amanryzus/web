var express=require('express');
var bodyparser=require('body-parser');
var urlencoded=bodyparser.urlencoded({extended:false});
var app=express();
var MongoClient=require('mongodb').MongoClient;

MongoClient.connect('mongodb://127.0.0.1/mydb',function(err,db){
	if(!err)console.log('connected');

	app.use(express.static('public'));
	app.use(bodyparser.json());

	app.get('/index.html',function(req,res){
	res.sendFile(__dirname+"/"+"index.html");	
	})
	app.get('/insert.html',function(req,res){
	res.sendFile(__dirname+"/"+"insert.html");	
	})
	/* ----------INSERT POST ---------------*/
	app.post('/process_post',function(req,res){
	res.setHeader('Content-Type', 'text/html');
	var empid=req.body.empid;
	var empname=req.body.empname;

	db.collection('employee').insert({empid:empid,empname:empname});
 	res.end("Employee Inserted-->"+JSON.stringify(req.body));
	});


	/*--------------SEARCH----------------*/
	app.get('/search.html',function(req,res){
	res.sendFile(__dirname+"/"+"search.html");	
	})
	app.get("/search", function(req, res) {
	//var empidnum=parseInt(req.query.empid)  // if empid is an integer
	var empidnum=req.query.empid;
    db.collection('employee').find({empid: empidnum}).toArray(function(err, docs) {
    if (err) {
      console.log(err.message+ "Failed to get data.");
    } else {
      res.status(200).json(docs);
    }
  });
  });
	/*--------------------Display---------*/
	app.get('/display',function(req,res){
	db.collection('employee').find().toArray(function(err,docs){
	if(!err){
	res.status(200).json(docs);	
	}	
	});
	});

	/*------------Update-------------*/
	app.get('/update.html',function(req,res){
	res.sendFile(__dirname+"/"+"update.html");	
	})
	app.get('/update',function(req,res){
	var empidold=req.query.empidold;
	var empidnew=req.query.empidnew;
	db.collection("employee").update({empid:empidold},{$set:{empid:empidnew}},{multi:true},function(err,result){
	if(!err) res.send(result);
	});	
	});
	
	/*------------Delete-------------*/
	app.get('/delete.html',function(req,res){
	res.sendFile(__dirname+"/"+"update.html");	
	})
	app.get('/delete',function(req,res){
	var empid=req.query.empid;
	
	db.collection("employee").remove({empid:empid},function(err,result){
	if(!err) res.send(result);
	});	
	});

	
});


 
var server = app.listen(5000, function () {  
var host = server.address().address  
  var port = server.address().port  
console.log("Example app listening at http://%s:%s", host, port)  
})  


